DELETE FROM `gk_cronscheduler_items` WHERE `command_internal` = "\\App\\AlgoliaSearch::processRunUpdateIndex";
