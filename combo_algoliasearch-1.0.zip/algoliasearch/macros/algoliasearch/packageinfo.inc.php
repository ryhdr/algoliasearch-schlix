<?php

$name = 'Algolia Search';
$type = 'macro';
$guid = 'ae1c30be-e191-1304-e1fa-17c648aa2733';
$version = '1.0';
$license = 'MIT';
$description = '';
$author = 'Roy Hadrianoro';
$url = 'https://www.schlix.com';
$email = 'roy.hadrianoro@schlix.com';
$copyright = 'Copyright &copy;2019 Roy Hadrianoro';