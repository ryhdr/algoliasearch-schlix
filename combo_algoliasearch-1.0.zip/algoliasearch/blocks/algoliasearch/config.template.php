<?php
/**
 * Algolia Search - Config
 * 
 * 
 *
 * 
 *
 * @copyright 2019 Roy Hadrianoro
 *
 * @license MIT
 *
 * @package algoliasearch
 * @version 1.0
 * @author  Roy Hadrianoro <roy.hadrianoro@schlix.com>
 * @link    https://www.schlix.com
 */
if (!defined('SCHLIX_VERSION'))
    die('No Access');
?>
<br />
<p>This block will display algolia search box.</p>
<p>Please use configuration in the app.</p>
